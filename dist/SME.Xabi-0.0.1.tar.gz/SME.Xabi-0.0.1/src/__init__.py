from .cor_im_pares import cor_im
from .discretizacion import discretize
from .escala import scale_x
from .filtrado import filtrado
from .metricas import calc_auc, calcular_metricas
from .plots import plot_roc, plot_cor_im